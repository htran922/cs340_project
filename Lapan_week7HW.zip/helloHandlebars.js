var express = require('express');

var app = express();
var handlebars = require('express-handlebars').create({defaultLayout:'main'});

app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
app.set('port', 4935);













//Prints h1 text depending on if a GET or POST is received
function getOrPost(req,res){
  var title = req.route.methods;
  if(req.route.methods.get == true){
    title = "GET Request Received";
  }
  else if(req.route.methods.post == true){
    title = "POST Request Received";
  };
  return title;
}

//Populate GET request data into list
app.get('/',function(req,res){
  var context = {};
  context.title = getOrPost(req,res);
  
  var qParams = [];
  for (var p in req.query){
    qParams.push({'name' :p, 'value' :req.query[p]})
  }
  context.dataList = qParams;
  res.render('home', context);
});







//Adds json parser to the app
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


//Populate Post request into lists
app.post('/', function(req,res){
  var qParams = [];
  var qBody = [];
  for (var p in req.body){
    qBody.push({'name':p,'value':req.body[p]})
  }
  for (var p in req.headers){
    qParams.push({'name':p, 'value':req.headers[p]})
  }
  var context = {};
  context.dataList = qParams;
  context.POSTlist = qBody;
  console.log(req.body);
  context.title = getOrPost(req,res);
  res.render('home', context);
});






/*app.get('/other-page',function(req,res){
  res.render('other-page');
});


function genContext(){
  var stuffToDisplay = {};
  stuffToDisplay.time = (new Date(Date.now())).toLocaleTimeString('en-US');
  stuffToDisplay.title = "Fake title";
  return stuffToDisplay;
}

app.get('/time',function(req,res){
  res.render('time', genContext());
});*/

app.use(function(req,res){
  res.status(404);
  res.render('404');
});

app.use(function(err, req, res, next){
  console.error(err.stack);
  res.type('plain/text');
  res.status(500);
  res.render('500');
});

app.listen(app.get('port'), function(){
  console.log('Express started on http://localhost:' + app.get('port') + '; press Ctrl-C to terminate.');
});
